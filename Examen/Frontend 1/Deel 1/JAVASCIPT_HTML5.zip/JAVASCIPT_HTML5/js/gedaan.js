function gedaan(){

    if( document.formulier.f_antwoord1.value!="" )
            {
                document.getElementById("vraag_1").style.opacity= "0.5";
            }

    if( document.formulier.f_antwoord1.value=="" )
            {
                document.getElementById("vraag_1").style.opacity= "1";
            }



    if( document.formulier.f_antwoord2.value!="" )
            {
                document.getElementById("vraag_2").style.opacity= "0.5";
            }

    if( document.formulier.f_antwoord2.value=="" )
            {
                document.getElementById("vraag_2").style.opacity= "1";
            }



    if( document.formulier.f_antwoord3.value!="" )
            {
                document.getElementById("vraag_3").style.opacity= "0.5";
            }

    if( document.formulier.f_antwoord3.value=="" )
            {
                document.getElementById("vraag_3").style.opacity= "1";
            }



    if( document.formulier.f_antwoord4.value!="" )
            {
                document.getElementById("vraag_4").style.opacity= "0.5";
            }

    if( document.formulier.f_antwoord4.value=="" )
            {
                document.getElementById("vraag_4").style.opacity= "1";
            }



    if( document.formulier.f_antwoord5.value!="" )
            {
                document.getElementById("vraag_5").style.opacity= "0.5";
            }

    if( document.formulier.f_antwoord5.value=="" )
            {
                document.getElementById("vraag_5").style.opacity= "1";
            }



    if( document.formulier.f_antwoord6.value!="" )
            {
                document.getElementById("vraag_6").style.opacity= "0.5";
            }

    if( document.formulier.f_antwoord6.value=="" )
            {
                document.getElementById("vraag_6").style.opacity= "1";
            }



    if( document.formulier.f_antwoord7.value!="" )
            {
                document.getElementById("vraag_7").style.opacity= "0.5";
            }

    if( document.formulier.f_antwoord7.value=="" )
            {
                document.getElementById("vraag_7").style.opacity= "1";
            }



    if( document.formulier.f_antwoord8.value!="" )
            {
                document.getElementById("vraag_8").style.opacity= "0.5";
            }

    if( document.formulier.f_antwoord8.value=="" )
            {
                document.getElementById("vraag_8").style.opacity= "1";
            }
}